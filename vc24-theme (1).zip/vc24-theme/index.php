<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>VURAN Consulting – Unternehmensberatung Berlin</title>
<meta name="description" content="VURAN Consulting UG – Ihr Partner für Unternehmensberatung, Personalvermittlung und Finanzierung in Berlin." />
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet" />
<style>
:root{--navy:#0d1b2a;--navy-mid:#162032;--gold:#c9a84c;--gold-light:#e8c96a;--white:#f7f4ef;--gray:#8a9ab0;--card-bg:#132030;--border:rgba(201,168,76,0.18);--radius:12px}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{font-family:'DM Sans',sans-serif;background:var(--navy);color:var(--white);font-size:16px;line-height:1.6;overflow-x:hidden}
nav{position:fixed;top:0;left:0;right:0;z-index:100;display:flex;align-items:center;justify-content:space-between;padding:0 6vw;height:72px;background:rgba(13,27,42,0.95);backdrop-filter:blur(12px);border-bottom:1px solid var(--border)}
.nav-logo{font-family:'Syne',sans-serif;font-weight:800;font-size:1.4rem;color:var(--gold);letter-spacing:-0.5px;text-decoration:none}
.nav-logo span{color:var(--white)}
.nav-links{display:flex;gap:2rem;list-style:none}
.nav-links a{color:var(--gray);text-decoration:none;font-size:0.88rem;font-weight:500;letter-spacing:0.04em;text-transform:uppercase;transition:color 0.2s}
.nav-links a:hover{color:var(--gold)}
.nav-cta{background:var(--gold)!important;color:var(--navy)!important;padding:0.45rem 1.2rem;border-radius:6px;font-weight:600!important}
.nav-cta:hover{background:var(--gold-light)!important}
.hamburger{display:none;flex-direction:column;gap:5px;cursor:pointer;border:none;background:none;padding:4px}
.hamburger span{display:block;width:24px;height:2px;background:var(--white);border-radius:2px}
#hero{min-height:100vh;display:flex;align-items:center;padding:120px 6vw 80px;position:relative;overflow:hidden}
.hero-bg{position:absolute;inset:0;z-index:0;background:radial-gradient(ellipse 70% 60% at 80% 40%,rgba(201,168,76,0.07) 0%,transparent 70%),radial-gradient(ellipse 50% 80% at 10% 80%,rgba(22,32,50,0.9) 0%,transparent 70%)}
.hero-grid{position:absolute;inset:0;z-index:0;background-image:linear-gradient(rgba(201,168,76,0.04) 1px,transparent 1px),linear-gradient(90deg,rgba(201,168,76,0.04) 1px,transparent 1px);background-size:60px 60px}
.hero-content{position:relative;z-index:1;max-width:700px}
.hero-badge{display:inline-flex;align-items:center;gap:0.5rem;background:rgba(201,168,76,0.12);border:1px solid var(--border);border-radius:100px;padding:0.35rem 1rem;font-size:0.78rem;font-weight:500;color:var(--gold);letter-spacing:0.06em;text-transform:uppercase;margin-bottom:1.8rem;animation:fadeUp 0.6s ease both}
.hero-badge::before{content:'';width:7px;height:7px;background:var(--gold);border-radius:50%}
h1{font-family:'Syne',sans-serif;font-size:clamp(2.4rem,5vw,4rem);font-weight:800;line-height:1.1;letter-spacing:-1px;margin-bottom:1.4rem;animation:fadeUp 0.6s 0.1s ease both}
h1 .gold{color:var(--gold)}
.hero-sub{font-size:1.1rem;color:var(--gray);max-width:520px;margin-bottom:2.4rem;font-weight:300;animation:fadeUp 0.6s 0.2s ease both}
.hero-btns{display:flex;gap:1rem;flex-wrap:wrap;animation:fadeUp 0.6s 0.3s ease both}
.btn-primary{background:var(--gold);color:var(--navy);padding:0.85rem 2rem;border-radius:8px;font-weight:600;font-size:0.95rem;text-decoration:none;transition:background 0.2s,transform 0.15s;display:inline-block;border:none;cursor:pointer;font-family:'DM Sans',sans-serif}
.btn-primary:hover{background:var(--gold-light);transform:translateY(-2px)}
.btn-outline{border:1px solid var(--border);color:var(--white);padding:0.85rem 2rem;border-radius:8px;font-weight:500;font-size:0.95rem;text-decoration:none;transition:border-color 0.2s,color 0.2s;display:inline-block}
.btn-outline:hover{border-color:var(--gold);color:var(--gold)}
.hero-stats{display:flex;gap:3rem;margin-top:4rem;animation:fadeUp 0.6s 0.4s ease both}
.stat-num{font-family:'Syne',sans-serif;font-size:2rem;font-weight:800;color:var(--gold)}
.stat-label{font-size:0.82rem;color:var(--gray);margin-top:0.2rem}
#audience{padding:80px 6vw;text-align:center}
.section-label{font-size:0.78rem;letter-spacing:0.1em;text-transform:uppercase;color:var(--gold);font-weight:600;margin-bottom:0.8rem}
h2{font-family:'Syne',sans-serif;font-size:clamp(1.8rem,3.5vw,2.6rem);font-weight:700;letter-spacing:-0.5px;margin-bottom:0.8rem}
.section-sub{color:var(--gray);max-width:500px;margin:0 auto 3rem}
.audience-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1.5rem;max-width:900px;margin:0 auto}
.audience-card{background:var(--card-bg);border:1px solid var(--border);border-radius:var(--radius);padding:2rem 1.5rem;text-decoration:none;color:var(--white);transition:border-color 0.2s,transform 0.2s,box-shadow 0.2s}
.audience-card:hover{border-color:var(--gold);transform:translateY(-4px);box-shadow:0 16px 40px rgba(0,0,0,0.4)}
.audience-icon{font-size:2.2rem;margin-bottom:1rem}
.audience-card h3{font-family:'Syne',sans-serif;font-size:1.05rem;font-weight:700;margin-bottom:0.5rem}
.audience-card p{font-size:0.88rem;color:var(--gray)}
.audience-arrow{display:inline-flex;align-items:center;gap:0.4rem;font-size:0.82rem;color:var(--gold);margin-top:1rem;font-weight:500}
#leistungen{padding:80px 6vw;background:var(--navy-mid)}
.services-header{max-width:600px;margin-bottom:3rem}
.section-divider{width:40px;height:3px;background:var(--gold);border-radius:2px;margin-bottom:1rem}
.services-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:1.5rem}
.service-card{background:var(--navy);border:1px solid var(--border);border-radius:var(--radius);padding:2rem;transition:border-color 0.2s,transform 0.2s}
.service-card:hover{border-color:var(--gold);transform:translateY(-3px)}
.service-num{font-family:'Syne',sans-serif;font-size:0.75rem;font-weight:700;color:var(--gold);letter-spacing:0.1em;margin-bottom:1rem}
.service-card h3{font-family:'Syne',sans-serif;font-size:1.05rem;font-weight:700;margin-bottom:0.8rem}
.service-card p{font-size:0.88rem;color:var(--gray);margin-bottom:1rem}
.service-tags{display:flex;flex-wrap:wrap;gap:0.4rem}
.tag{background:rgba(201,168,76,0.1);color:var(--gold);border:1px solid rgba(201,168,76,0.2);padding:0.2rem 0.65rem;border-radius:100px;font-size:0.75rem;font-weight:500}
#referenzen{padding:80px 6vw;text-align:center}
.testimonials-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1.5rem;margin-top:3rem;text-align:left}
.testimonial-card{background:var(--card-bg);border:1px solid var(--border);border-radius:var(--radius);padding:2rem}
.stars{color:var(--gold);font-size:1rem;margin-bottom:1rem;letter-spacing:2px}
.testimonial-text{font-size:0.9rem;color:var(--gray);font-style:italic;margin-bottom:1.4rem}
.testimonial-author{font-weight:600;font-size:0.9rem}
.testimonial-role{font-size:0.8rem;color:var(--gray)}
#team{padding:80px 6vw;background:var(--navy-mid)}
.team-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:1.5rem;margin-top:3rem}
.team-card{background:var(--navy);border:1px solid var(--border);border-radius:var(--radius);padding:2rem;text-align:center}
.team-avatar{width:72px;height:72px;border-radius:50%;background:linear-gradient(135deg,var(--gold) 0%,#8a6a20 100%);display:flex;align-items:center;justify-content:center;font-family:'Syne',sans-serif;font-size:1.4rem;font-weight:800;color:var(--navy);margin:0 auto 1rem}
.team-card h3{font-family:'Syne',sans-serif;font-weight:700;margin-bottom:0.3rem}
.team-card p{font-size:0.85rem;color:var(--gold);margin-bottom:0.5rem}
.team-card span{font-size:0.82rem;color:var(--gray)}
#jobs{padding:80px 6vw}
.jobs-tabs{display:flex;gap:1rem;margin-bottom:2rem;flex-wrap:wrap}
.tab-btn{padding:0.6rem 1.5rem;border-radius:100px;border:1px solid var(--border);background:transparent;color:var(--gray);font-family:'DM Sans',sans-serif;font-size:0.88rem;font-weight:500;cursor:pointer;transition:all 0.2s}
.tab-btn.active,.tab-btn:hover{background:var(--gold);color:var(--navy);border-color:var(--gold)}
.jobs-content{display:none}
.jobs-content.active{display:block}
.form-box{background:var(--card-bg);border:1px solid var(--border);border-radius:var(--radius);padding:2.5rem;max-width:700px}
.form-box h3{font-family:'Syne',sans-serif;font-size:1.3rem;font-weight:700;margin-bottom:0.4rem}
.form-desc{color:var(--gray);font-size:0.88rem;margin-bottom:1.8rem}
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:1rem}
.form-full{grid-column:1/-1}
label{display:block;font-size:0.82rem;font-weight:500;color:var(--gray);margin-bottom:0.4rem;letter-spacing:0.03em}
input,textarea,select{width:100%;background:var(--navy);border:1px solid var(--border);border-radius:8px;padding:0.75rem 1rem;color:var(--white);font-family:'DM Sans',sans-serif;font-size:0.9rem;transition:border-color 0.2s;outline:none}
input:focus,textarea:focus,select:focus{border-color:var(--gold)}
textarea{resize:vertical;min-height:100px}
select option{background:var(--navy)}
.form-check{display:flex;align-items:flex-start;gap:0.6rem;font-size:0.82rem;color:var(--gray);margin:1rem 0}
.form-check input[type="checkbox"]{width:auto;margin-top:3px;accent-color:var(--gold)}
.form-check a{color:var(--gold)}
#kontakt{padding:80px 6vw;background:var(--navy-mid)}
.kontakt-layout{display:grid;grid-template-columns:1fr 1.4fr;gap:4rem;align-items:start;max-width:960px}
.contact-info h2{font-family:'Syne',sans-serif;font-size:1.8rem;font-weight:700;margin-bottom:1rem}
.contact-info p{color:var(--gray);margin-bottom:2rem;font-size:0.92rem}
.contact-item{display:flex;gap:0.8rem;align-items:flex-start;margin-bottom:1.2rem}
.contact-icon{width:36px;height:36px;background:rgba(201,168,76,0.12);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:1rem;flex-shrink:0}
.contact-item-text a{color:var(--gold);text-decoration:none;font-size:0.9rem}
.contact-item-text a:hover{text-decoration:underline}
.contact-item-text span{font-size:0.78rem;color:var(--gray);display:block}
footer{background:var(--navy);border-top:1px solid var(--border);padding:2rem 6vw;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1rem}
footer p{font-size:0.82rem;color:var(--gray)}
.footer-links{display:flex;gap:1.5rem}
.footer-links a{font-size:0.82rem;color:var(--gray);text-decoration:none}
.footer-links a:hover{color:var(--gold)}
@keyframes fadeUp{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
@media(max-width:768px){
  .nav-links{display:none}
  .hamburger{display:flex}
  .nav-links.open{display:flex;flex-direction:column;position:absolute;top:72px;left:0;right:0;background:var(--navy-mid);padding:1.5rem 6vw;border-bottom:1px solid var(--border);gap:1.2rem}
  .audience-grid{grid-template-columns:1fr}
  .testimonials-grid{grid-template-columns:1fr}
  .form-grid{grid-template-columns:1fr}
  .kontakt-layout{grid-template-columns:1fr;gap:2rem}
  .hero-stats{gap:2rem}
}
</style>
</head>
<body>

<nav>
  <a href="#" class="nav-logo">VC<span>24</span></a>
  <ul class="nav-links" id="navLinks">
    <li><a href="#leistungen">Leistungen</a></li>
    <li><a href="#referenzen">Referenzen</a></li>
    <li><a href="#team">Team</a></li>
    <li><a href="#vorratsgesellschaften">Vorratsgesellschaft</a></li>
    <li><a href="#jobs">Jobs</a></li>
    <li><a href="#kontakt" class="nav-cta">Beratung anfragen</a></li>
  </ul>
  <button class="hamburger" onclick="document.getElementById('navLinks').classList.toggle('open')" aria-label="Menü">
    <span></span><span></span><span></span>
  </button>
</nav>

<section id="hero">
  <div class="hero-bg"></div>
  <div class="hero-grid"></div>
  <div class="hero-content">
    <div class="hero-badge">🏙 Ihr Partner in Berlin</div>
    <h1>Beratung, die Ihr<br>Unternehmen <span class="gold">wirklich</span><br>voranbringt.</h1>
    <p class="hero-sub">Von der Gründung über ISO-Zertifizierung bis zur Personalgewinnung – VURAN Consulting begleitet Sie mit Erfahrung und Klarheit.</p>
    <div class="hero-btns">
      <a href="#kontakt" class="btn-primary">Kostenlos anfragen</a>
      <a href="#leistungen" class="btn-outline">Leistungen entdecken</a>
    </div>
    <div class="hero-stats">
      <div><div class="stat-num">7+</div><div class="stat-label">Beratungsfelder</div></div>
      <div><div class="stat-num">Berlin</div><div class="stat-label">Hauptstandort</div></div>
      <div><div class="stat-num">100%</div><div class="stat-label">Persönliche Betreuung</div></div>
    </div>
  </div>
</section>

<section id="audience">
  <p class="section-label">Wen wir begleiten</p>
  <h2>Was bringt Sie zu uns?</h2>
  <p class="section-sub">Wählen Sie Ihre Situation – wir zeigen Ihnen genau, was wir für Sie tun können.</p>
  <div class="audience-grid">
    <a href="#leistungen" class="audience-card">
      <div class="audience-icon">🚀</div>
      <h3>Ich gründe ein Unternehmen</h3>
      <p>Rechtsform, Businessplan, Fördermittel – wir begleiten Sie vom ersten Tag an.</p>
      <div class="audience-arrow">Mehr erfahren →</div>
    </a>
    <a href="#leistungen" class="audience-card">
      <div class="audience-icon">🏢</div>
      <h3>Ich suche Beratung oder Personal</h3>
      <p>Prozessoptimierung, Zertifizierungen, Finanzanalyse und Personalgewinnung aus einer Hand.</p>
      <div class="audience-arrow">Mehr erfahren →</div>
    </a>
    <a href="#jobs" class="audience-card">
      <div class="audience-icon">💼</div>
      <h3>Ich suche eine neue Stelle</h3>
      <p>Wir vermitteln Fachkräfte und unterstützen bei der Jobsuche in Berlin und Umgebung.</p>
      <div class="audience-arrow">Jetzt bewerben →</div>
    </a>
  </div>
</section>

<section id="leistungen">
  <div class="services-header">
    <p class="section-label">Was wir bieten</p>
    <div class="section-divider"></div>
    <h2>Unsere Leistungen</h2>
    <p style="color:var(--gray);margin-top:0.6rem">Umfassende Beratung – abgestimmt auf Ihre Ziele und Ihre Branche.</p>
  </div>
  <div class="services-grid">
    <div class="service-card"><div class="service-num">01</div><h3>Neugründung & Business Setup</h3><p>Von der Rechtsformwahl über den Businessplan bis zum ersten Bankgespräch – strukturiert und zuverlässig.</p><div class="service-tags"><span class="tag">Rechtsformwahl</span><span class="tag">Businessplan</span><span class="tag">Fördermittelcheck</span></div></div>
    <div class="service-card"><div class="service-num">02</div><h3>Prozessoptimierung</h3><p>Engpässe erkennen, Abläufe digitalisieren, Kennzahlen etablieren – damit Ihr Unternehmen effizienter wächst.</p><div class="service-tags"><span class="tag">IST-Analyse</span><span class="tag">Digitalisierung</span><span class="tag">DMS & Workflows</span></div></div>
    <div class="service-card"><div class="service-num">03</div><h3>ISO 9001 & AZAV-Zertifizierung</h3><p>Von der QM-Einführung bis zur Auditvorbereitung – wir machen Ihr Unternehmen zertifizierungsbereit.</p><div class="service-tags"><span class="tag">ISO 9001</span><span class="tag">AZAV</span><span class="tag">Interne Audits</span></div></div>
    <div class="service-card"><div class="service-num">04</div><h3>Personalgewinnung & -planung</h3><p>Vom Stellenprofil bis zum Onboarding – wir finden die richtigen Mitarbeiter und stärken Ihr Employer Branding.</p><div class="service-tags"><span class="tag">Active Sourcing</span><span class="tag">Employer Branding</span><span class="tag">Interviewleitfäden</span></div></div>
    <div class="service-card"><div class="service-num">05</div><h3>Finanzanalyse & -planung</h3><p>Liquidität sichern, Finanzierungsoptionen vergleichen, KPI-Dashboards aufbauen – für fundierte Entscheidungen.</p><div class="service-tags"><span class="tag">Kredit & Leasing</span><span class="tag">Factoring</span><span class="tag">KPI-Dashboards</span></div></div>
    <div class="service-card"><div class="service-num">06</div><h3>Arbeitnehmerüberlassung (AÜG)</h3><p>Rechtssicheres Setup, Compliance und Dokumentation – für flexiblen Personaleinsatz.</p><div class="service-tags"><span class="tag">AÜG-Compliance</span><span class="tag">Disposition</span><span class="tag">Qualitätssicherung</span></div></div>
    <div class="service-card"><div class="service-num">07</div><h3>Fördermittel & Antragstellung</h3><p>Wir identifizieren passende Förderprogramme, übernehmen die Antragstellung und begleiten das Projektcontrolling.</p><div class="service-tags"><span class="tag">Förderprogramme</span><span class="tag">Antragstellung</span><span class="tag">Verwendungsnachweise</span></div></div>
  </div>
</section>

<section id="referenzen">
  <p class="section-label">Was unsere Kunden sagen</p>
  <h2>Vertrauen, das zählt</h2>
  <p class="section-sub">Erfahrungen aus echten Projekten – von Unternehmen aus Berlin und Umgebung.</p>
  <div class="testimonials-grid">
    <div class="testimonial-card"><div class="stars">★★★★★</div><p class="testimonial-text">„VURAN Consulting hat uns durch den gesamten AZAV-Zertifizierungsprozess begleitet – strukturiert, kompetent und immer erreichbar. Die Zulassung haben wir auf Anhieb erhalten."</p><div class="testimonial-author">Bildungsträger Berlin</div><div class="testimonial-role">Geschäftsführung</div></div>
    <div class="testimonial-card"><div class="stars">★★★★★</div><p class="testimonial-text">„Dank der Fördermittelberatung konnten wir unsere Digitalisierung komplett fördern lassen. Ohne VC24 hätten wir die passenden Programme nie gefunden."</p><div class="testimonial-author">Handwerksbetrieb, Berlin-Mitte</div><div class="testimonial-role">Inhaber</div></div>
    <div class="testimonial-card"><div class="stars">★★★★★</div><p class="testimonial-text">„Die Personalvermittlung lief professionell und schnell ab. Innerhalb von drei Wochen hatten wir zwei qualifizierte Mitarbeiter – genau wie besprochen."</p><div class="testimonial-author">IT-Startup, Berlin</div><div class="testimonial-role">HR-Leitung</div></div>
  </div>
</section>

<section id="team">
  <p class="section-label">Wer wir sind</p>
  <div class="section-divider"></div>
  <h2>Unser Team</h2>
  <p style="color:var(--gray);margin-top:0.6rem;max-width:500px">Menschen mit Erfahrung, Haltung und dem Anspruch, Ihrem Unternehmen echten Mehrwert zu bringen.</p>
  <div class="team-grid">
    <div class="team-card"><div class="team-avatar">V</div><h3>Geschäftsführung</h3><p>VURAN Consulting UG</p><span>Strategie · Finanzen · Beratung</span></div>
    <div class="team-card"><div class="team-avatar">HR</div><h3>Personalberatung</h3><p>Recruiting & Placement</p><span>Active Sourcing · Employer Branding</span></div>
    <div class="team-card"><div class="team-avatar">QM</div><h3>Qualitätsmanagement</h3><p>Zertifizierung & Compliance</p><span>ISO 9001 · AZAV · Audits</span></div>
  </div>
</section>

<section id="jobs">
  <p class="section-label">Karriere & Stellenangebote</p>
  <h2>Jobs & Bewerbung</h2>
  <p style="color:var(--gray);margin-top:0.5rem;margin-bottom:2rem">Für Arbeitgeber und Arbeitssuchende – alles an einem Ort.</p>
  <div class="jobs-tabs">
    <button class="tab-btn active" onclick="switchTab('bewerben',this)">Ich möchte mich bewerben</button>
    <button class="tab-btn" onclick="switchTab('ausschreiben',this)">Stelle ausschreiben</button>
  </div>
  <div id="bewerben" class="jobs-content active">
    <div class="form-box">
      <h3>Bewerberprofil erstellen</h3>
      <p class="form-desc">Hinterlegen Sie Ihr Profil – wir melden uns, wenn eine passende Stelle verfügbar ist.</p>
      <div class="form-grid">
        <div><label>Vorname</label><input type="text" placeholder="Max"/></div>
        <div><label>Nachname</label><input type="text" placeholder="Mustermann"/></div>
        <div><label>E-Mail</label><input type="email" placeholder="max@email.de"/></div>
        <div><label>Telefon</label><input type="tel" placeholder="+49 30 …"/></div>
        <div><label>Bevorzugte Stelle</label><input type="text" placeholder="z.B. Projektmanager"/></div>
        <div><label>Verfügbar ab</label><input type="date"/></div>
        <div><label>Gehaltsvorstellung (€/Jahr)</label><input type="text" placeholder="z.B. 45.000"/></div>
        <div><label>Führerschein</label><input type="text" placeholder="z.B. Klasse B"/></div>
        <div class="form-full"><label>Fähigkeiten & Erfahrung</label><textarea placeholder="Kurze Beschreibung Ihrer Qualifikationen …"></textarea></div>
        <div class="form-full"><label>Lebenslauf (PDF)</label><input type="file" accept=".pdf"/></div>
      </div>
      <div class="form-check"><input type="checkbox" id="dsg1"/><label for="dsg1">Ich akzeptiere die <a href="/datenschutz">Datenschutzhinweise</a>.</label></div>
      <button class="btn-primary">Profil absenden</button>
    </div>
  </div>
  <div id="ausschreiben" class="jobs-content">
    <div class="form-box">
      <h3>Stellenangebot einstellen</h3>
      <p class="form-desc">Erreichen Sie qualifizierte Kandidaten – wir kümmern uns um die Vermittlung.</p>
      <div class="form-grid">
        <div><label>Unternehmen</label><input type="text" placeholder="Firmenname"/></div>
        <div><label>Ansprechpartner:in</label><input type="text" placeholder="Ihr Name"/></div>
        <div><label>E-Mail</label><input type="email" placeholder="hr@firma.de"/></div>
        <div><label>Telefon</label><input type="tel" placeholder="+49 …"/></div>
        <div><label>Jobtitel</label><input type="text" placeholder="z.B. Buchhalterin (m/w/d)"/></div>
        <div><label>Standort</label><input type="text" placeholder="Berlin"/></div>
        <div><label>Beschäftigungsart</label><select><option>Vollzeit</option><option>Teilzeit</option><option>Minijob</option><option>Freelance</option></select></div>
        <div><label>Startdatum</label><input type="date"/></div>
        <div class="form-full"><label>Aufgaben & Anforderungen</label><textarea placeholder="Beschreiben Sie die Position …"></textarea></div>
      </div>
      <div class="form-check"><input type="checkbox" id="dsg2"/><label for="dsg2">Ich akzeptiere die <a href="/datenschutz">Datenschutzhinweise</a>.</label></div>
      <button class="btn-primary">Stelle veröffentlichen</button>
    </div>
  </div>
</section>

<section id="kontakt">
  <div class="kontakt-layout">
    <div class="contact-info">
      <p class="section-label">Kontakt</p>
      <h2>Sprechen wir.<br>Kostenlos & unverbindlich.</h2>
      <p>Sie haben Fragen oder möchten ein konkretes Projekt besprechen? Wir melden uns innerhalb von 24 Stunden.</p>
      <div class="contact-item"><div class="contact-icon">📍</div><div class="contact-item-text"><span>Adresse</span><a href="https://maps.google.com/?q=Klemkestraße+43+13409+Berlin" target="_blank">Klemkestraße 43, 13409 Berlin</a></div></div>
      <div class="contact-item"><div class="contact-icon">✉️</div><div class="contact-item-text"><span>E-Mail</span><a href="mailto:info@vc24.berlin">info@vc24.berlin</a></div></div>
      <div class="contact-item"><div class="contact-icon">📞</div><div class="contact-item-text"><span>Telefon</span><a href="tel:+493023320589">+49 (0)30 233 205 89</a></div></div>
    </div>
    <div class="form-box">
      <h3>Kurze Anfrage senden</h3>
      <p class="form-desc">Wir antworten werktags innerhalb von 24 Stunden.</p>
      <div class="form-grid">
        <div class="form-full"><label>Ihr Name</label><input type="text" placeholder="Max Mustermann"/></div>
        <div><label>E-Mail</label><input type="email" placeholder="max@firma.de"/></div>
        <div><label>Telefon</label><input type="tel" placeholder="+49 …"/></div>
        <div class="form-full"><label>Ihre Nachricht</label><textarea placeholder="Womit können wir Ihnen helfen?" style="min-height:130px"></textarea></div>
      </div>
      <div class="form-check"><input type="checkbox" id="dsg3"/><label for="dsg3">Ich akzeptiere die <a href="/datenschutz">Datenschutzhinweise</a>.</label></div>
      <button class="btn-primary" style="width:100%">Nachricht senden</button>
    </div>
  </div>
</section>

<!-- VORRATSGESELLSCHAFTEN -->
<section id="vorratsgesellschaften" style="padding:80px 6vw">
  <div style="max-width:960px">
    <p class="section-label">Schnell & rechtssicher</p>
    <div class="section-divider"></div>
    <h2>Vorratsgesellschaften kaufen</h2>
    <p style="color:var(--gray);margin-top:0.6rem;max-width:600px;margin-bottom:3rem">Sie möchten sofort geschäftsfähig sein? Eine Vorratsgesellschaft ermöglicht Ihnen den schnellen Einstieg – ohne Wartezeit auf Neugründung, mit sauberer Handelsregister-Historie.</p>

    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:1.5rem;margin-bottom:3rem">
      <div class="service-card">
        <div style="font-size:2rem;margin-bottom:1rem">🏛️</div>
        <h3 style="font-family:'Syne',sans-serif;font-size:1.05rem;font-weight:700;margin-bottom:0.6rem">GmbH Vorratsgesellschaft</h3>
        <p style="font-size:0.88rem;color:var(--gray);margin-bottom:1rem">Sofort einsetzbare GmbH mit bestehendem Handelsregistereintrag. Kein Warten, kein Notartermin für die Gründung.</p>
        <div class="service-tags"><span class="tag">Sofort verfügbar</span><span class="tag">HRB eingetragen</span></div>
      </div>
      <div class="service-card">
        <div style="font-size:2rem;margin-bottom:1rem">⚡</div>
        <h3 style="font-family:'Syne',sans-serif;font-size:1.05rem;font-weight:700;margin-bottom:0.6rem">UG Vorratsgesellschaft</h3>
        <p style="font-size:0.88rem;color:var(--gray);margin-bottom:1rem">Günstige Alternative zur GmbH – ideal für Startups und kleinere Projekte, die schnell starten wollen.</p>
        <div class="service-tags"><span class="tag">Geringes Stammkapital</span><span class="tag">Flexibel</span></div>
      </div>
      <div class="service-card">
        <div style="font-size:2rem;margin-bottom:1rem">✅</div>
        <h3 style="font-family:'Syne',sans-serif;font-size:1.05rem;font-weight:700;margin-bottom:0.6rem">Komplettpaket</h3>
        <p style="font-size:0.88rem;color:var(--gray);margin-bottom:1rem">Wir übernehmen die Umschreibung, Beratung und alle notwendigen Schritte – Sie erhalten die Gesellschaft schlüsselfertig.</p>
        <div class="service-tags"><span class="tag">Beratung inklusive</span><span class="tag">Rundum-Service</span></div>
      </div>
    </div>

    <!-- Vorteile -->
    <div style="background:var(--card-bg);border:1px solid var(--border);border-radius:var(--radius);padding:2.5rem;margin-bottom:3rem">
      <h3 style="font-family:'Syne',sans-serif;font-size:1.2rem;font-weight:700;margin-bottom:1.5rem;color:var(--gold)">Warum eine Vorratsgesellschaft?</h3>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:1.2rem">
        <div style="display:flex;gap:0.8rem;align-items:flex-start">
          <div style="width:32px;height:32px;background:rgba(201,168,76,0.12);border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0">⏱️</div>
          <div><div style="font-weight:600;font-size:0.9rem;margin-bottom:0.2rem">Sofort einsatzbereit</div><div style="font-size:0.82rem;color:var(--gray)">Kein Warten auf Gründung oder Notartermin</div></div>
        </div>
        <div style="display:flex;gap:0.8rem;align-items:flex-start">
          <div style="width:32px;height:32px;background:rgba(201,168,76,0.12);border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0">📋</div>
          <div><div style="font-weight:600;font-size:0.9rem;margin-bottom:0.2rem">Saubere Historie</div><div style="font-size:0.82rem;color:var(--gray)">Keine Verbindlichkeiten, keine Altlasten</div></div>
        </div>
        <div style="display:flex;gap:0.8rem;align-items:flex-start">
          <div style="width:32px;height:32px;background:rgba(201,168,76,0.12);border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0">🔒</div>
          <div><div style="font-weight:600;font-size:0.9rem;margin-bottom:0.2rem">Haftungsbeschränkung</div><div style="font-size:0.82rem;color:var(--gray)">Volle GmbH-/UG-Struktur vom ersten Tag an</div></div>
        </div>
        <div style="display:flex;gap:0.8rem;align-items:flex-start">
          <div style="width:32px;height:32px;background:rgba(201,168,76,0.12);border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0">🤝</div>
          <div><div style="font-weight:600;font-size:0.9rem;margin-bottom:0.2rem">Beratung inklusive</div><div style="font-size:0.82rem;color:var(--gray)">Wir begleiten Sie durch den gesamten Prozess</div></div>
        </div>
      </div>
    </div>

    <!-- CTA -->
    <div style="background:linear-gradient(135deg,rgba(201,168,76,0.12) 0%,rgba(201,168,76,0.04) 100%);border:1px solid var(--border);border-radius:var(--radius);padding:2.5rem;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1.5rem">
      <div>
        <h3 style="font-family:'Syne',sans-serif;font-size:1.3rem;font-weight:700;margin-bottom:0.5rem">Interesse? Wir beraten Sie persönlich.</h3>
        <p style="color:var(--gray);font-size:0.9rem;max-width:480px">Teilen Sie uns kurz Ihren Bedarf mit – wir prüfen die Verfügbarkeit und melden uns innerhalb von 24 Stunden mit einem konkreten Angebot.</p>
      </div>
      <a href="#kontakt-vorrats" class="btn-primary" style="white-space:nowrap">Jetzt anfragen</a>
    </div>
  </div>
</section>

<!-- KONTAKT VORRATSGESELLSCHAFT -->
<section id="kontakt-vorrats" style="padding:80px 6vw;background:var(--navy-mid)">
  <div style="max-width:700px">
    <p class="section-label">Vorratsgesellschaft anfragen</p>
    <h2>Interesse an einer Vorratsgesellschaft?</h2>
    <p style="color:var(--gray);margin-top:0.6rem;margin-bottom:2rem">Füllen Sie das Formular aus – wir melden uns schnellstmöglich mit verfügbaren Gesellschaften und Preisen.</p>
    <div class="form-box">
      <h3>Anfrage stellen</h3>
      <p class="form-desc">Kostenlos & unverbindlich – wir beraten Sie individuell.</p>
      <div class="form-grid">
        <div><label>Ihr Name</label><input type="text" placeholder="Max Mustermann"/></div>
        <div><label>Unternehmen (optional)</label><input type="text" placeholder="Ihre Firma"/></div>
        <div><label>E-Mail</label><input type="email" placeholder="max@email.de"/></div>
        <div><label>Telefon</label><input type="tel" placeholder="+49 …"/></div>
        <div class="form-full">
          <label>Gewünschte Gesellschaftsform</label>
          <select>
            <option value="">Bitte wählen …</option>
            <option>GmbH Vorratsgesellschaft</option>
            <option>UG Vorratsgesellschaft</option>
            <option>Noch nicht sicher – Beratung gewünscht</option>
          </select>
        </div>
        <div class="form-full"><label>Ihre Nachricht / Verwendungszweck (optional)</label><textarea placeholder="Für welchen Zweck benötigen Sie die Gesellschaft? Gibt es besondere Anforderungen?"></textarea></div>
      </div>
      <div class="form-check"><input type="checkbox" id="dsg4"/><label for="dsg4">Ich akzeptiere die <a href="/datenschutz">Datenschutzhinweise</a>.</label></div>
      <button class="btn-primary" style="width:100%">Anfrage absenden</button>
    </div>
  </div>
</section>

<footer>
  <p>© 2026 VURAN Consulting UG (Haftungsbeschränkt) · Klemkestraße 43, 13409 Berlin</p>
  <div class="footer-links">
    <a href="/impressum">Impressum</a>
    <a href="/datenschutz">Datenschutz</a>
  </div>
</footer>

<script>
function switchTab(id,btn){
  document.querySelectorAll('.jobs-content').forEach(c=>c.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  btn.classList.add('active');
}
</script>
</body>
</html>
